//
// Created by maks on 13/06/23.
//

#include "FastaA.h"
#include "biocpp.h"

namespace biocpp {
	FastaA::FastaA(std::string file_path) : FastaN(file_path) {};
	
	RecordA FastaA::get_next_record() {
		if (this->file_handle.eof()) {
			std::cout << "There are no more records to read\n";
			RecordA record("", "");
			return record;
		}
		std::string record_seq;
		std::string record_name;
		getline(this->file_handle, record_name);
		record_name.erase(0, 1);
		getline(this->file_handle, record_seq);
		
		RecordA record(record_name, record_seq);
		
		if (this->file_handle.eof()) {
			std::cout << "You reached end of file, no more record to read\n";
		}
		
		return record;
	}
	
} // biocpp
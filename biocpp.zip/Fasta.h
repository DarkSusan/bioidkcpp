//
// Created by maks on 26/05/23.
//

#ifndef BIOCPP_FASTA_H
#define BIOCPP_FASTA_H
#include <filesystem>
#include <iostream>
#include <fstream>
#include <tuple>

using namespace std::filesystem;

namespace biocpp {
	class Fasta {
	
	protected:
		int record_num = 0;
		float mean_record_len;
		path file_path;
		std::string fasta_content_type;
		std::ifstream file_handle;
	public:
		Fasta(std::string file_path);
		
		std::string get_file_name();
		
		int get_record_num();
		
		float get_mean_record_len();
		
		// ToDo: Make this virtual so this class cannot be initialised, but after testing
		std::tuple<std::string, std::string> get_next_record();
	};
};

#endif //BIOCPP_FASTA_H

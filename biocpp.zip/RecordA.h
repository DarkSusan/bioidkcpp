//
// Created by maks on 13/06/23.
//

#ifndef BIOCPP_RECORDA_H
#define BIOCPP_RECORDA_H
#include "biocpp.h"

using namespace biocpp;
using namespace std;

namespace biocpp {
	
	class RecordA : public RecordN {
	public:
		RecordA(string name, string seq);
	
	};
	
} // biocpp

#endif //BIOCPP_RECORDA_H

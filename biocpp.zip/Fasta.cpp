//
// Created by maks on 26/05/23.
//

#include "Fasta.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <tuple>

using namespace std::filesystem;
using namespace biocpp;

biocpp::Fasta::Fasta(std::string file_path) {
	this->file_path = path(file_path);
	this->fasta_content_type = this->file_path.extension().string().erase(0, 1);
	std::ifstream fasta_file(path(file_path).generic_string());
	std::string line;
	int record_len = 0;
	float record_len_sum = 0;
	int record_num = 0;
	bool first_record = true;
	while (!fasta_file.eof()) {
		getline(fasta_file, line);
		int record_start = line.find('>');
		if (record_start != std::string::npos) {
			if (first_record) {
				record_num++;
				first_record = false;
				continue;
			}
			record_len_sum += record_len;
			record_len = 0;
			record_num++;
		} else {
			record_len = record_len + line.length();
		}
	}
	record_len_sum += record_len;
	this->file_handle.open(this->file_path);
	this->mean_record_len = record_len_sum/record_num;
	this->record_num = record_num;
};

int biocpp::Fasta::get_record_num() {
	return this->record_num;
}

std::string biocpp::Fasta::get_file_name() {
	return this->file_path.stem();
}

float biocpp::Fasta::get_mean_record_len() {
	return this->mean_record_len;
}

std::tuple<std::string, std::string> biocpp::Fasta::get_next_record() {
	if (!this->file_handle.is_open()) {
		std::cout << "There are no more records to read\n";
		return std::make_tuple("", "");
	}
	std::string line;
	std::string record_seq;
	std::string record_name;
	getline(this->file_handle, line);
	record_name = line;
	getline(this->file_handle, line);
	record_seq = line;
	
	return std::make_tuple(record_name, record_seq);
}

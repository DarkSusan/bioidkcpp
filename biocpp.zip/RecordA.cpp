//
// Created by maks on 13/06/23.
//

#include "RecordA.h"

namespace biocpp {
	RecordA::RecordA(std::string name, std::string seq) : RecordN(name, seq){}
} // biocpp
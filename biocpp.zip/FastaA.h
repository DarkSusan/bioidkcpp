//
// Created by maks on 13/06/23.
//

#ifndef BIOCPP_FASTAA_H
#define BIOCPP_FASTAA_H
#include "biocpp.h"
#include "RecordA.h"

using namespace biocpp;
using namespace std;

namespace biocpp {
	
	class FastaA : public FastaN {
	public:
		FastaA (string file_path);
		
		RecordA get_next_record();
	};
	
} // biocpp

#endif //BIOCPP_FASTAA_H
